"""
This code is modified version of the <https://github.com/wolny/pytorch-3dunet> repository.
"""
